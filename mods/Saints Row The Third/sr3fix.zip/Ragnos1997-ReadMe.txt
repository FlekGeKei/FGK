Saints Row The Third Low Specs patch upto v1.16 FINAL
------------------------------------------------
v1.11 FINAL
-Forced 640x480
-Shadows forced off
-Big changes were made in game options
-Huge lag fixes
-Crash fix after using flying jets
v1.15 FINAL
-Forced 320x240(for ultra low graphics cards)-custom resolution must be added in nvidia/catalyst control panels
v1.16 FINAL
-Forced 480x360(for ultra low graphics cards)-custom resolution must be added in nvidia/catalyst control panels
------------------------------------------------
I hope this stuff helped some people with low ranked graphics card to run Saints Row The Third on playable FPS.

Contact me at:
ragnos1997-octeam@hotmail.com
or
https://www.facebook.com/Ragnos1997OFCyt

Feel free to contact me whenever you want!
Fly Safe!