Female Animation Replacements and Fixes V.1
___________________
plyf.xtbl edited by MLVNRT
___________________
Description:
	Featuring an animation mod that replaces the original pistol sprint animation with the unarmed female sprint animation. This mod only works for female characters. Male character animations will not change.

The reason why the original pistol sprint animation seems rigid is because it is actually using the unarmed male sprint animation. The female sprint animation features looser shoulder movement in comparison. Once the mod is installed, the animations should flow more smoothly from running to sprinting.

Changes:
	-Female pistol sprint is more fluid (male base sprint replaced with female base sprint)

	-Female sniper animations is the female rifle animations (male sniper animations replaced with female rifle animations)
___________________
Instructions:
Step 1- Extract archive
Step 2- Move 'tables' folder into...
	 ...C:\Program Files (x86)\Steam\steamapps\common\Saints Row the Third
Step 3- Launch SRTT game
Step 4- Play as a female character to notice the differences in pistol sprinting and sniper animations.
___________________
Troubleshooting:
	Make such you have 'plyf.xtbl' in the/a 'tables' folder or folder named 'tables' or the mod will not work.
( ...C:\Program Files (x86)\Steam\steamapps\common\Saints Row the Third\tables\plyf.xtbl)
___________________
Open for suggestions:
	https://www.saintsrowmods.com/forum/members/mlvnrt.204275/